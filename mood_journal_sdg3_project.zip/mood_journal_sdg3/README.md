# Mood Journal – SDG 3 (Good Health & Well‑Being)

AI‑powered emotion tracker turning daily journal entries into mood insights.

## Features
- User auth (signup/login/logout) with hashed passwords
- CRUD journal entries
- Hugging Face Inference API sentiment analysis
- Chart.js mood trends
- M‑Pesa (Daraja STK Push) payments in **KSh**
- Responsive UI (mobile, tablet, desktop)
- PWA: manifest + service worker

## Tech Stack
Frontend: HTML, CSS, JS, Chart.js  
Backend: Flask (Python), Flask‑Login, SQLAlchemy  
Database: MySQL (PyMySQL)  
AI: Hugging Face Inference API  
Payments: Safaricom M‑Pesa (Daraja STK Push)  
Media: Images (Pexels.com), YouTube embed

## Setup
1. Create DB
```bash
mysql -u root -p < schema.sql
```
2. Configure `.env`
```bash
cp .env.example .env
```
3. Install & run
```bash
python -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```
App: http://localhost:5000

## M‑Pesa
- Get sandbox keys at developer.safaricom.co.ke
- Expose callback URL publicly (ngrok or domain)
- Set `MPESA_CALLBACK_URL` to `https://<domain>/api/payments/mpesa/callback`

## Deployment
- Gunicorn: `gunicorn -w 2 -b 0.0.0.0:8000 app:create_app()`
- Use Nginx/Render/Railway/Azure/Heroku (ClearDB for MySQL).

Contacts: +254 704 072 989 • karanikevo@gmail.com
