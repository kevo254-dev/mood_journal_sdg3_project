from flask import Flask, render_template, request, jsonify, redirect, url_for
from flask_login import LoginManager, login_user, login_required, logout_user, current_user
from werkzeug.security import generate_password_hash, check_password_hash
from models import db, User, JournalEntry, Payment
from config import Config
from utils.hf_client import analyze_sentiment
from utils.mpesa import stk_push
import re

def create_app():
    app = Flask(__name__)
    app.config.from_object(Config)
    db.init_app(app)

    login_manager = LoginManager()
    login_manager.login_view = 'login'
    login_manager.init_app(app)

    @login_manager.user_loader
    def load_user(user_id):
        return User.query.get(int(user_id))

    @app.route('/')
    def index():
        if current_user.is_authenticated:
            return redirect(url_for('dashboard'))
        return render_template('index.html')

    @app.route('/dashboard')
    @login_required
    def dashboard():
        return render_template('dashboard.html', currency=Config.DEFAULT_CURRENCY)

    @app.post('/register')
    def register():
        data = request.get_json() or request.form
        email = (data.get('email') or '').strip().lower()
        phone = (data.get('phone') or '').strip()
        password = (data.get('password') or '').strip()

        if not email or not password:
            return jsonify({'ok': False, 'error': 'Email and password are required'}), 400
        if User.query.filter_by(email=email).first():
            return jsonify({'ok': False, 'error': 'Email already registered'}), 409
        if phone and not re.match(r'^\+?\d{10,15}$', phone):
            return jsonify({'ok': False, 'error': 'Invalid phone format'}), 400

        user = User(email=email, phone=phone, password_hash=generate_password_hash(password))
        db.session.add(user)
        db.session.commit()
        return jsonify({'ok': True})

    @app.post('/login')
    def login():
        data = request.get_json() or request.form
        email = (data.get('email') or '').strip().lower()
        password = (data.get('password') or '').strip()
        user = User.query.filter_by(email=email).first()
        if not user or not check_password_hash(user.password_hash, password):
            return jsonify({'ok': False, 'error': 'Invalid credentials'}), 401
        login_user(user)
        return jsonify({'ok': True})

    @app.get('/logout')
    @login_required
    def logout():
        logout_user()
        return redirect(url_for('index'))

    @app.get('/api/entries')
    @login_required
    def list_entries():
        entries = JournalEntry.query.filter_by(user_id=current_user.id).order_by(JournalEntry.created_at.asc()).all()
        return jsonify([{
            'id': e.id,
            'text': e.text,
            'emotion_label': e.emotion_label,
            'emotion_score': e.emotion_score,
            'created_at': e.created_at.isoformat()
        } for e in entries])

    @app.post('/api/entries')
    @login_required
    def add_entry():
        data = request.get_json() or {}
        text = (data.get('text') or '').strip()
        if not text:
            return jsonify({'ok': False, 'error': 'Text required'}), 400
        result = analyze_sentiment(text)
        entry = JournalEntry(user_id=current_user.id, text=text, emotion_label=result.get('label'), emotion_score=result.get('score'))
        db.session.add(entry)
        db.session.commit()
        return jsonify({'ok': True, 'entry': {
            'id': entry.id, 'text': entry.text, 'emotion_label': entry.emotion_label, 'emotion_score': entry.emotion_score, 'created_at': entry.created_at.isoformat()
        }})

    @app.delete('/api/entries/<int:entry_id>')
    @login_required
    def delete_entry(entry_id):
        entry = JournalEntry.query.filter_by(id=entry_id, user_id=current_user.id).first_or_404()
        db.session.delete(entry)
        db.session.commit()
        return jsonify({'ok': True})

    @app.post('/api/payments/stkpush')
    @login_required
    def initiate_payment():
        data = request.get_json() or {}
        amount = int(data.get('amount') or 250)
        phone = data.get('phone') or current_user.phone
        if not phone:
            return jsonify({'ok': False, 'error': 'Phone number required'}), 400
        try:
            resp = stk_push(amount=amount, phone=phone)
            crid = resp.get('CheckoutRequestID')
            pay = Payment(user_id=current_user.id, amount=amount, phone=phone, checkout_request_id=crid)
            db.session.add(pay)
            db.session.commit()
            return jsonify({'ok': True, 'checkout_request_id': crid, 'response': resp})
        except Exception as e:
            return jsonify({'ok': False, 'error': str(e)}), 500

    @app.post('/api/payments/mpesa/callback')
    def mpesa_callback():
        data = request.get_json() or {}
        crid = data.get('Body', {}).get('stkCallback', {}).get('CheckoutRequestID')
        result_code = data.get('Body', {}).get('stkCallback', {}).get('ResultCode')
        items = data.get('Body', {}).get('stkCallback', {}).get('CallbackMetadata', {}).get('Item', [])
        receipt = None
        for item in items:
            if item.get('Name') == 'MpesaReceiptNumber':
                receipt = item.get('Value')
        if crid:
            pay = Payment.query.filter_by(checkout_request_id=crid).first()
            if pay:
                pay.status = 'success' if result_code == 0 else 'failed'
                pay.mpesa_receipt = receipt
                db.session.commit()
        return jsonify({'ok': True})

    return app

if __name__ == "__main__":
    app = create_app()
    with app.app_context():
        db.create_all()
    app.run(host="0.0.0.0", port=5000)
