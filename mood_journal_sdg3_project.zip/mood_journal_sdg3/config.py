import os
from dotenv import load_dotenv
load_dotenv()
class Config:
    SECRET_KEY = os.getenv("FLASK_SECRET_KEY","dev-secret")
    DEBUG = os.getenv("FLASK_DEBUG","0") == "1"
    SQLALCHEMY_DATABASE_URI = "mysql+pymysql://{u}:{p}@{h}:{pt}/{d}".format(
        u=os.getenv("DB_USER","root"),
        p=os.getenv("DB_PASSWORD",""),
        h=os.getenv("DB_HOST","127.0.0.1"),
        pt=os.getenv("DB_PORT","3306"),
        d=os.getenv("DB_NAME","moodjournal"),
    )
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    HF_MODEL = os.getenv("HF_MODEL","distilbert-base-uncased-finetuned-sst-2-english")
    HF_TOKEN = os.getenv("HF_TOKEN","").strip()
    MPESA_ENV = os.getenv("MPESA_ENV","sandbox")
    MPESA_CONSUMER_KEY = os.getenv("MPESA_CONSUMER_KEY","")
    MPESA_CONSUMER_SECRET = os.getenv("MPESA_CONSUMER_SECRET","")
    MPESA_BUSINESS_SHORT_CODE = os.getenv("MPESA_BUSINESS_SHORT_CODE","")
    MPESA_PASSKEY = os.getenv("MPESA_PASSKEY","")
    MPESA_CALLBACK_URL = os.getenv("MPESA_CALLBACK_URL","")
    DEFAULT_CURRENCY = os.getenv("DEFAULT_CURRENCY","KES")
