// Helper: fetch JSON
async function jfetch(url, opts={}){
  const res = await fetch(url, Object.assign({ headers: { 'Content-Type':'application/json' }}, opts));
  if(!res.ok){
    const t = await res.text();
    throw new Error(t || res.statusText);
  }
  return res.json();
}

// Auth modal handlers
const loginModal = document.getElementById('login-modal');
const registerModal = document.getElementById('register-modal');
document.querySelectorAll('.js-open-login')?.forEach(el => el.addEventListener('click', () => loginModal?.showModal()));
document.querySelectorAll('.js-open-register')?.forEach(el => el.addEventListener('click', () => registerModal?.showModal()));
document.querySelector('.js-switch-login')?.addEventListener('click', (e)=>{ e.preventDefault(); registerModal?.close(); loginModal?.showModal(); });
document.querySelector('.js-switch-register')?.addEventListener('click', (e)=>{ e.preventDefault(); loginModal?.close(); registerModal?.showModal(); });

document.getElementById('login-submit')?.addEventListener('click', async (e)=>{
  e.preventDefault();
  const form = document.getElementById('login-form');
  const payload = { email: form.email.value, password: form.password.value };
  try {
    const data = await jfetch('/login', { method:'POST', body: JSON.stringify(payload) });
    if(data.ok){ window.location.href = '/dashboard'; }
  } catch(err){ alert('Login failed: ' + err.message); }
});

document.getElementById('register-submit')?.addEventListener('click', async (e)=>{
  e.preventDefault();
  const form = document.getElementById('register-form');
  const payload = { email: form.email.value, password: form.password.value, phone: form.phone.value };
  try {
    const data = await jfetch('/register', { method:'POST', body: JSON.stringify(payload) });
    if(data.ok){ alert('Account created. Please login.'); registerModal?.close(); loginModal?.showModal(); }
  } catch(err){ alert('Registration failed: ' + err.message); }
});

// Dashboard logic
async function loadEntries(){
  const list = document.getElementById('entriesList');
  if(!list) return;
  const data = await jfetch('/api/entries');
  list.innerHTML = '';
  const labels = [];
  const scores = [];
  data.forEach(e => {
    labels.push(new Date(e.created_at).toLocaleDateString());
    scores.push(e.emotion_score || 0);
    const li = document.createElement('li');
    li.innerHTML = `<div>
      <div class="meta">${new Date(e.created_at).toLocaleString()}</div>
      <div><strong>${e.emotion_label || 'neutral'}</strong> • ${e.emotion_score ?? 0}%</div>
      <div>${e.text.replace(/[<>]/g,'')}</div>
    </div>
    <div>
      <button class="btn-outline" data-id="${e.id}" data-action="delete">Delete</button>
    </div>`;
    list.appendChild(li);
  });
  renderChart(labels, scores);
  list.addEventListener('click', async (ev)=>{
    const btn = ev.target.closest('button[data-action="delete"]');
    if(btn){
      const id = btn.getAttribute('data-id');
      if(confirm('Delete this entry?')){
        await jfetch(`/api/entries/${id}`, { method: 'DELETE' });
        await loadEntries();
      }
    }
  }, { once:true });
}

function renderChart(labels, scores){
  const ctx = document.getElementById('moodChart');
  if(!ctx) return;
  if(window._moodChart){ window._moodChart.destroy(); }
  window._moodChart = new Chart(ctx, {
    type: 'line',
    data: {
      labels,
      datasets: [{
        label: 'Emotion Score (%)',
        data: scores,
        tension: 0.25
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: { min: 0, max: 100, ticks: { stepSize: 20 } }
      }
    }
  });
}

document.getElementById('entry-form')?.addEventListener('submit', async (e)=>{
  e.preventDefault();
  const text = document.getElementById('entry').value.trim();
  if(!text) return;
  const btn = e.submitter || e.target.querySelector('button[type="submit"]');
  btn.disabled = true;
  try {
    await jfetch('/api/entries', { method: 'POST', body: JSON.stringify({ text }) });
    document.getElementById('entry').value = '';
    await loadEntries();
  } catch(err){
    alert('Failed to save: ' + err.message);
  } finally { btn.disabled = false; }
});

document.getElementById('pay-premium')?.addEventListener('click', async ()=>{
  const phone = prompt('Enter your M-Pesa phone number in international format (e.g., +2547XXXXXXXX):');
  if(!phone) return;
  try {
    const res = await jfetch('/api/payments/stkpush', { method:'POST', body: JSON.stringify({ amount: 250, phone }) });
    if(res.ok){
      alert('Payment prompt sent. Check your phone to authorize the KSh 250 payment.');
    } else {
      alert('Payment failed: ' + (res.error || 'Unknown error'));
    }
  } catch(err){
    alert('Payment error: ' + err.message);
  }
});

if(document.getElementById('entriesList')){
  loadEntries();
}
