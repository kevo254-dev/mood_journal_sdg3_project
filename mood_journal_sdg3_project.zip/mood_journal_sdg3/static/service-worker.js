// Simple offline-first caching for static assets
const CACHE = 'moodjournal-v1';
const ASSETS = ['/', '/static/css/styles.css', '/static/js/app.js'];
self.addEventListener('install', (e)=>{
  e.waitUntil(caches.open(CACHE).then(cache => cache.addAll(ASSETS)));
});
self.addEventListener('fetch', (e)=>{
  const url = new URL(e.request.url);
  if(url.pathname.startsWith('/static/')){
    e.respondWith(caches.match(e.request).then(resp => resp || fetch(e.request)));
  }
});
