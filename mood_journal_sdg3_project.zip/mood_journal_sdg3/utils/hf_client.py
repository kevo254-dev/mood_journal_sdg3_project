import requests
from config import Config

def analyze_sentiment(text: str):
    if not text.strip():
        return {"label": "neutral", "score": 0.0}
    url = f"https://api-inference.huggingface.co/models/{Config.HF_MODEL}"
    headers = {"Content-Type": "application/json"}
    if Config.HF_TOKEN:
        headers["Authorization"] = f"Bearer {Config.HF_TOKEN}"
    resp = requests.post(url, headers=headers, json={"inputs": text}, timeout=20)
    if resp.status_code == 503:
        return {"label": "loading", "score": 0.0}
    resp.raise_for_status()
    data = resp.json()
    label, score = "neutral", 0.0
    try:
        if isinstance(data, list) and data and isinstance(data[0], list):
            best = max(data[0], key=lambda x: x.get("score", 0))
            label = best.get("label","neutral"); score = round(float(best.get("score",0.0))*100,2)
        elif isinstance(data, list) and data:
            best = max(data, key=lambda x: x.get("score", 0))
            label = best.get("label","neutral"); score = round(float(best.get("score",0.0))*100,2)
        elif isinstance(data, dict) and "label" in data:
            label = data.get("label","neutral"); score = round(float(data.get("score",0.0))*100,2)
    except Exception:
        pass
    mapping = {"POSITIVE":"happy", "NEGATIVE":"sad"}
    mood = mapping.get(label.upper(), label.lower())
    return {"label": mood, "score": score}
