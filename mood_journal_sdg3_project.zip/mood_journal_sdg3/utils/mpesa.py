import base64, requests, datetime
from config import Config

DARAJA_BASE = "https://sandbox.safaricom.co.ke" if Config.MPESA_ENV == "sandbox" else "https://api.safaricom.co.ke"

def get_access_token():
    auth = (Config.MPESA_CONSUMER_KEY, Config.MPESA_CONSUMER_SECRET)
    url = f"{DARAJA_BASE}/oauth/v1/generate?grant_type=client_credentials"
    r = requests.get(url, auth=auth, timeout=10)
    r.raise_for_status()
    return r.json()["access_token"]

def _timestamp():
    return datetime.datetime.now().strftime("%Y%m%d%H%M%S")

def _password(ts: str):
    data = f"{Config.MPESA_BUSINESS_SHORT_CODE}{Config.MPESA_PASSKEY}{ts}"
    return base64.b64encode(data.encode()).decode()

def stk_push(amount: int, phone: str, account_reference: str = "MoodJournal", description: str = "Premium"):
    token = get_access_token()
    ts = _timestamp()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {
        "BusinessShortCode": Config.MPESA_BUSINESS_SHORT_CODE,
        "Password": _password(ts),
        "Timestamp": ts,
        "TransactionType": "CustomerPayBillOnline",
        "Amount": amount,
        "PartyA": phone,
        "PartyB": Config.MPESA_BUSINESS_SHORT_CODE,
        "PhoneNumber": phone,
        "CallBackURL": Config.MPESA_CALLBACK_URL,
        "AccountReference": account_reference,
        "TransactionDesc": description,
    }
    url = f"{DARAJA_BASE}/mpesa/stkpush/v1/processrequest"
    r = requests.post(url, headers=headers, json=payload, timeout=15)
    r.raise_for_status()
    return r.json()

def stk_query(checkout_request_id: str):
    token = get_access_token()
    ts = _timestamp()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}
    payload = {
        "BusinessShortCode": Config.MPESA_BUSINESS_SHORT_CODE,
        "Password": _password(ts),
        "Timestamp": ts,
        "CheckoutRequestID": checkout_request_id,
    }
    url = f"{DARAJA_BASE}/mpesa/stkpushquery/v1/query"
    r = requests.post(url, headers=headers, json=payload, timeout=15)
    r.raise_for_status()
    return r.json()
